import 'package:flutter/material.dart';

class ListScreen extends StatelessWidget {
  const ListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, String>> destinations = [
      {'name': 'Paris', 'description': 'The city of lights and love in France.'},
      {'name': 'Tokyo', 'description': 'A bustling capital blending tradition and technology.'},
      {'name': 'New York', 'description': 'The city that never sleeps in the USA.'},
      {'name': 'Rome', 'description': 'Historic capital filled with ancient ruins and art.'},
      {'name': 'Dubai', 'description': 'Luxury shopping and modern architecture in UAE.'},
      {'name': 'London', 'description': 'A city of culture, history, and innovation.'},
      {'name': 'Sydney', 'description': 'Famous for its opera house and harbor views.'},
      {'name': 'Istanbul', 'description': 'Where East meets West, rich in history.'},
      {'name': 'Bali', 'description': 'Tropical paradise known for beaches and temples.'},
      {'name': 'Cairo', 'description': 'Home to the pyramids and ancient Egyptian culture.'},
    ];

    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Travel Destinations'),
          backgroundColor: Colors.blueAccent,
        ),
        body: ListView.builder(
          itemCount: destinations.length,
          itemBuilder: (context, index) {
            final destination = destinations[index];
            return Card(
              margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              elevation: 3,
              child: ListTile(
                leading: const Icon(Icons.location_on, color: Colors.blueAccent),
                title: Text(
                  destination['name']!,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
                subtitle: Text(destination['description']!),
              ),
            );
          },
        ),
      ),
    );
  }
}
